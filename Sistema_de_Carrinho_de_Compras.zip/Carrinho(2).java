import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

public class Carrinho {
    private List<Produto> produtos;

    public Carrinho() {
        produtos = new ArrayList<>();
    }

    public void adicionarProduto(String nome, double preco) {
        Produto produto = new Produto(nome, preco);
        produtos.add(produto);

        System.out.println("Produto adicionado ao carrinho.");
    }

    public void listarProdutos() {
        if (produtos.isEmpty()) {
            System.out.println("O carrinho está vazio.");
            return;
        }

        System.out.println("\n--- Produtos no carrinho ---");

        for (int i = 0; i < produtos.size(); i++) {
            System.out.println((i + 1) + " - " + produtos.get(i));
        }
    }

    public void ordenarPorNomeCrescente() {
        produtos.sort(Comparator.comparing(Produto::getNome));

        System.out.println("Produtos ordenados por nome em ordem crescente.");
    }

    public void ordenarPorNomeDecrescente() {
        produtos.sort(
                Comparator.comparing(Produto::getNome).reversed()
        );

        System.out.println("Produtos ordenados por nome em ordem decrescente.");
    }

    public void ordenarPorPrecoCrescente() {
        produtos.sort(Comparator.comparingDouble(Produto::getPreco));

        System.out.println("Produtos ordenados por preço em ordem crescente.");
    }

    public void ordenarPorPrecoDecrescente() {
        produtos.sort(
                Comparator.comparingDouble(Produto::getPreco).reversed()
        );

        System.out.println("Produtos ordenados por preço em ordem decrescente.");
    }

    public boolean removerProduto(String nomeProduto) {
        Iterator<Produto> iterator = produtos.iterator();

        while (iterator.hasNext()) {
            Produto produto = iterator.next();

            if (produto.getNome().equalsIgnoreCase(nomeProduto)) {
                iterator.remove();
                return true;
            }
        }

        return false;
    }

    public boolean carrinhoVazio() {
        return produtos.isEmpty();
    }
}