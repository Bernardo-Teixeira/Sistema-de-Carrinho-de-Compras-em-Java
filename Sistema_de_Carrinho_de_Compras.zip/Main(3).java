import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Carrinho carrinho = new Carrinho();

        int opcao;

        do {
            exibirMenu();

            System.out.print("Digite uma opção: ");
            opcao = scanner.nextInt();
            scanner.nextLine();

            switch (opcao) {
                case 1:
                    cadastrarProduto(scanner, carrinho);
                    break;

                case 2:
                    carrinho.listarProdutos();
                    break;

                case 3:
                    carrinho.ordenarPorNomeCrescente();
                    carrinho.listarProdutos();
                    break;

                case 4:
                    carrinho.ordenarPorNomeDecrescente();
                    carrinho.listarProdutos();
                    break;

                case 5:
                    carrinho.ordenarPorPrecoCrescente();
                    carrinho.listarProdutos();
                    break;

                case 6:
                    carrinho.ordenarPorPrecoDecrescente();
                    carrinho.listarProdutos();
                    break;

                case 7:
                    removerProduto(scanner, carrinho);
                    break;

                case 0:
                    System.out.println("Programa encerrado.");
                    break;

                default:
                    System.out.println("Opção inválida.");
            }

        } while (opcao != 0);

        scanner.close();
    }

    public static void exibirMenu() {
        System.out.println("\n   CARRINHO DE COMPRAS ");
        System.out.println("1 - Adicionar produto");
        System.out.println("2 - Listar produtos");
        System.out.println("3 - Ordenar por nome crescente");
        System.out.println("4 - Ordenar por nome decrescente");
        System.out.println("5 - Ordenar por preço crescente");
        System.out.println("6 - Ordenar por preço decrescente");
        System.out.println("7 - Remover produto");
        System.out.println("0 - Sair");
    }

    public static void cadastrarProduto(
            Scanner scanner,
            Carrinho carrinho
    ) {
        System.out.print("Nome do produto: ");
        String nome = scanner.nextLine();

        System.out.print("Preço do produto: ");
        double preco = scanner.nextDouble();
        scanner.nextLine();

        carrinho.adicionarProduto(nome, preco);
    }

    public static void removerProduto(
            Scanner scanner,
            Carrinho carrinho
    ) {
        if (carrinho.carrinhoVazio()) {
            System.out.println("O carrinho está vazio.");
            return;
        }

        System.out.print("Nome do produto para remover: ");
        String nomeProduto = scanner.nextLine();

        boolean removido = carrinho.removerProduto(nomeProduto);

        if (removido) {
            System.out.println("Produto removido com sucesso.");
        } else {
            System.out.println("Produto não encontrado.");
        }
    }
}